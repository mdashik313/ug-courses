public class GlobalTimer {
    int time;
    public GlobalTimer(int initialTime){
        this.time=initialTime;
    }
}